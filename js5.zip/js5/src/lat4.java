// cread by ghenta alif alde_21343048
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class lat4 {
    public static void main(String[]args){
        BufferedReader dataIn= new BufferedReader(new InputStreamReader(System.in));
        
        String a,b;
        float angka1, angka2, jumlah;
        System.out.println("Program Penjumlahan Dua Buah Bilangan");

        try{
            System.out.print("Masuka  angka pertama:");
            a=dataIn.readLine();
            /*Data yang diproses aritmatika harus dikonversikan dulu dari tipe data Stiring ke tipe data angka
             yang di perlukan.Data yang diperoleh dari input kelas BufferedReade tipe datanya selalu String*/
             angka1=Float.parseFloat(a); //konversikan dari String ke float
             
             System.out.print("Masukan angka kedua:");
             b=dataIn.readLine();
             angka2=Float.parseFloat(b);//konversi dari String ke float

             jumlah = angka1+angka2;
             System.out.println("Jumlah:"+jumlah);
        }
        catch (IOException e){
            System.out.println("gagal membaca keyboard");
    }
 }
}