// cread by ghenta alif alde_21343048
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
public class tugas1 {
    public static void main(String[]args){
        Scanner dataMasuk =new Scanner(System.in);
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        String tampilan3=" ";

        System.out.print("Enter word1:");
        String tampilan1 =dataMasuk.nextLine();

        System.out.print("Enter word2:");
        String tampilan2 =dataMasuk.nextLine();

        try{
            System.out.print("Enter world3:");
            tampilan3= input.readLine();
        }
        catch (IOException e){
            System.out.println("gagal membaca keyboard");
        }
        System.out.println("\n" + tampilan1+""+tampilan2+""+tampilan3);
    }
}